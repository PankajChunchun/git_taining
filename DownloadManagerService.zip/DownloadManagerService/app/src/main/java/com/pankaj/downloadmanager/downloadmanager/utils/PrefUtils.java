package com.pankaj.downloadmanager.downloadmanager.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.pankaj.downloadmanager.downloadmanager.DownloadManagerService;
import com.pankaj.downloadmanager.downloadmanager.beans.DownloadStatus;
import com.pankaj.downloadmanager.downloadmanager.beans.DownloadableObject;

/**
 * Created by Pankaj Kumar on 7/16/2017.
 * pankaj.arrah@gmail.com
 */
public class PrefUtils {
    private static final String TAG = PrefUtils.class.getSimpleName();
    private static final String PREF_NAME = DownloadManagerService.class.getSimpleName().toLowerCase();
    private static final String KEY_PREFIX_DOWNLOAD = "dm";
    private static final String KEY_PREFIX_PERCENT = "pcnt";

    private Context mContext;
    private static PrefUtils _instance;
    private SharedPreferences mPrefs;

    private PrefUtils(Context context) {
        this.mContext = context;
        mPrefs = mContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static final PrefUtils getInstance(Context context) {
        if (_instance == null) {
            _instance = new PrefUtils(context);
        }
        return _instance;
    }

    public DownloadableObject getItem(Context context, DownloadableObject
            downloadableItem) {
        if (context == null || downloadableItem == null) {
            return downloadableItem;
        }
        String downloadingStatus = getDownloadStatus(context, downloadableItem.getId());
        int downloadPercent = getDownloadPercent(context, downloadableItem.getId());
        downloadableItem.setDownloadStatus(DownloadStatus.valueOf(downloadingStatus));
        downloadableItem.setDownloadPercent(downloadPercent);
        return downloadableItem;
    }

    public void persistItemState(Context context, DownloadableObject downloadableItem) {
        setDownloadPercent(context, downloadableItem.getId(),
                downloadableItem.getDownloadPercent());
        setDownloadStatus(context, downloadableItem.getId(),
                downloadableItem.getDownloadStatus());
    }

    public String getDownloadStatus(Context context, String itemId) {
        return mPrefs.getString(KEY_PREFIX_DOWNLOAD + itemId,
                DownloadStatus.NEW.name());
    }

    public void setDownloadStatus(Context context, String itemId, DownloadStatus downloadingStatus) {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putString(KEY_PREFIX_DOWNLOAD + itemId, downloadingStatus.name());
        editor.commit();
    }

    public int getDownloadPercent(Context context, String itemId) {
        return mPrefs.getInt(KEY_PREFIX_PERCENT + itemId, 0);
    }

    public void setDownloadPercent(Context context, String itemId, int percent) {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putInt(KEY_PREFIX_PERCENT + itemId, percent);
        editor.commit();
    }
}