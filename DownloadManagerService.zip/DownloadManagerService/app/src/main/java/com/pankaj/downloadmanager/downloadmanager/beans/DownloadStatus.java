package com.pankaj.downloadmanager.downloadmanager.beans;

import com.pankaj.downloadmanager.R;

/**
 * Created by Pankaj Kumar on 7/15/2017.
 * pankaj.arrah@gmail.com
 */
public enum DownloadStatus {
    NEW {
        @Override
        public int getIconId() {
            return R.drawable.status_new_icon;
        }
    },
    QUEUED {
        @Override
        public int getIconId() {
            return R.drawable.status_waiting_icon;
        }
    },
    IN_PROGRESS {
        @Override
        public int getIconId() {
            return R.drawable.status_new_icon;
        }
    },
    PAUSED {
        @Override
        public int getIconId() {
            return R.drawable.status_new_icon;
        }
    },
    FAILED {
        @Override
        public int getIconId() {
            return R.drawable.status_retry_icon;
        }
    },
    COMPLETED {
        @Override
        public int getIconId() {
            return R.drawable.status_completed_icon;
        }
    };

    abstract public int getIconId();
}
