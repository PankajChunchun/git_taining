package com.pankaj.downloadmanager.downloadmanager.utils;

import com.pankaj.downloadmanager.downloadmanager.DownloadManagerService;

/**
 * Created by Pankaj Kumar on 7/15/2017.
 * pankaj.arrah@gmail.com
 */
public final class Constants {
    private Constants() {
        throw new UnsupportedOperationException("Can not instanciated!!!");
    }

    public static final class DownloadConfig {
        public static final int DEFAULT_ID = -1;
        public static final int PERCENT_COMPLETED = 100;
        public static final int MAX_DOWNLOADS = 2;


        public final static int DEALAY_STATUS_QUERY = 200;
        public final static int MIN_DIFF_PRCNT_TO_EMIT_STATUS = 3;
    }

    public static final class Action {
        public static String ACTION_NEXT_DOWNLOAD = "com.pankaj.downloadmanager.NEXT_DOWNLOAD";
        public static String ACTION_PAUSE_DOWNLOAD = "com.pankaj.downloadmanager.PAUSE_DOWNLOAD";
        public static String ACTION_RETRY_DOWNLOAD = "com.pankaj.downloadmanager.RETRY_DOWNLOAD";
        public static String ACTION_STOP_DOWNLOAD_MANAGER = "com.pankaj.downloadmanager.STOP_DOWNLOAD_SERVICE";



        public static String MAIN_ACTION = "com.marothiatechs.foregroundservice.action.main";
        public static String INIT_ACTION = "com.marothiatechs.foregroundservice.action.init";
        public static String PREV_ACTION = "com.marothiatechs.foregroundservice.action.prev";
        public static String PLAY_ACTION = "com.marothiatechs.foregroundservice.action.play";
        public static String NEXT_ACTION = "com.marothiatechs.foregroundservice.action.next";
        public static String STARTFOREGROUND_ACTION = "com.marothiatechs.foregroundservice.action.startforeground";
        public static String STOPFOREGROUND_ACTION = "com.marothiatechs.foregroundservice.action.stopforeground";
    }

    public static final class Notification {
        public static int FOREGROUND_SERVICE_NID = 101;
    }
}
