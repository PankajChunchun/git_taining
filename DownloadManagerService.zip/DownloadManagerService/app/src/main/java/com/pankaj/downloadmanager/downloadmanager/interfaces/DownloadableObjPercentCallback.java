package com.pankaj.downloadmanager.downloadmanager.interfaces;

import com.pankaj.downloadmanager.downloadmanager.beans.DownloadableObject;

/**
 * Created by Pankaj Kumar on 7/16/2017.
 * pankaj.arrah@gmail.com
 */
public interface DownloadableObjPercentCallback {
    void updateDownloadableObject(DownloadableObject downloadableItem);
}
