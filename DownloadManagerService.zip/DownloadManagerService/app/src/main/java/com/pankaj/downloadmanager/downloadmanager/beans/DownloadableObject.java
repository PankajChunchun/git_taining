package com.pankaj.downloadmanager.downloadmanager.beans;

/**
 * Created by Pankaj Kumar on 7/15/2017.
 * pankaj.arrah@gmail.com
 */
public class DownloadableObject {
    private String id;
    private long dmId;
    private String objectName;
    private int itemCoverId;
    private DownloadStatus downloadStatus;
    private String objectUrl;
    private int downloadPercent;
    private int lastEmittedDownloadPercent = -1;

    public DownloadableObject() {

    }

    public DownloadableObject(String id, long dmId, String objectName, int itemCoverId, DownloadStatus downloadStatus, String objectUrl, int downloadPercent, int lastEmittedDownloadPercent) {
        this.id = id;
        this.dmId = dmId;
        this.objectName = objectName;
        this.itemCoverId = itemCoverId;
        this.downloadStatus = downloadStatus;
        this.objectUrl = objectUrl;
        this.downloadPercent = downloadPercent;
        this.lastEmittedDownloadPercent = lastEmittedDownloadPercent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getDmId() {
        return dmId;
    }

    public void setDmId(long dmId) {
        this.dmId = dmId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public int getItemCoverId() {
        return itemCoverId;
    }

    public void setItemCoverId(int itemCoverId) {
        this.itemCoverId = itemCoverId;
    }

    public DownloadStatus getDownloadStatus() {
        return downloadStatus;
    }

    public void setDownloadStatus(DownloadStatus downloadStatus) {
        this.downloadStatus = downloadStatus;
    }

    public String getObjectUrl() {
        return objectUrl;
    }

    public void setObjectUrl(String objectUrl) {
        this.objectUrl = objectUrl;
    }

    public int getDownloadPercent() {
        return downloadPercent;
    }

    public void setDownloadPercent(int downloadPercent) {
        this.downloadPercent = downloadPercent;
    }

    public int getLastEmittedDownloadPercent() {
        return lastEmittedDownloadPercent;
    }

    public void setLastEmittedDownloadPercent(int lastEmittedDownloadPercent) {
        this.lastEmittedDownloadPercent = lastEmittedDownloadPercent;
    }
}