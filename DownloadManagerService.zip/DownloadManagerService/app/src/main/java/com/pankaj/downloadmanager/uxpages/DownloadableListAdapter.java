package com.pankaj.downloadmanager.uxpages;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.pankaj.downloadmanager.R;
import com.pankaj.downloadmanager.downloadmanager.beans.DownloadableObject;
import com.pankaj.downloadmanager.downloadmanager.interfaces.DownloadableObjPercentCallback;
import com.pankaj.downloadmanager.downloadmanager.utils.DMPercentObserverHelper;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Created by 473708 on 7/11/2017.
 */

public class DownloadableListAdapter extends RecyclerView.Adapter<DownloadableListAdapter.ViewHolder> implements DownloadableObjPercentCallback {
    private ArrayList<DownloadableObject> mFiles;
    private final DMPercentObserverHelper mDmPercentObserverHelper;
    private final WeakReference<Context> mContextWeakReference;
    private final RecyclerView mRecyclerView;

    // Provide a suitable constructor (depends on the kind of dataset)
    public DownloadableListAdapter(Context context, RecyclerView recyclerView, ArrayList<DownloadableObject> files) {
        this.mContextWeakReference = new WeakReference(context);
        this.mRecyclerView = recyclerView;
        this.mFiles = files;
        this.mDmPercentObserverHelper = new DMPercentObserverHelper(this);
    }





    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView mDownloadableFile;
        public ProgressBar mDownloadProgress;
        public ImageView mDownloadAction;

        public ViewHolder(View view) {
            super(view);
            mDownloadableFile = (TextView) view.findViewById(R.id.dm_obj_view_title);
            mDownloadProgress = (ProgressBar) view.findViewById(R.id.dm_obj_view_progress);
            mDownloadAction = (ImageView) view.findViewById(R.id.dm_obj_view_status);
        }
    }



    // Create new views (invoked by the layout manager)
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate view
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.downloadable_obj_layout, parent, false);
        // set the view's size, margins, paddings and layout parameters
        // ...

        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        final DownloadableObject row = mFiles.get(position);
        holder.mDownloadableFile.setText(row.getObjectUrl());
        getFileName(holder.mDownloadableFile, row.getObjectUrl());
        holder.mDownloadAction.setImageResource(row.getDownloadStatus().getIconId());
        holder.mDownloadProgress.setProgress(row.getDownloadPercent());
        holder.mDownloadAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), "Clicked on " + holder.mDownloadableFile.getText(), Toast.LENGTH_SHORT).show();
                switch (row.getDownloadStatus()) {
                    case NEW:
                    case FAILED:
                        downloadData(holder.mDownloadableFile.getText().toString(), Uri.parse(mFiles.get(position).getObjectUrl()));
                        break;
                    case PAUSED:
                        // TODO: Write logic to resume downloading
                        break;
                    case COMPLETED:
                    case QUEUED:
                        // TODO: Update UI if required.
                        // Ignore click in such cases
                        break;
                    default:
                        break;
                }
            }
        });
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mFiles.size();
    }

    private void getFileName(TextView tv, String url) {
        Uri returnUri = Uri.parse(url);
        File file = new File(returnUri.getPath());
        file.getName();
        tv.setText(file.getName());
    }

    private long downloadData(String fileName, Uri uri) {

        long downloadReference;

        // Create request for android download manager
        DownloadManager downloadManager = (DownloadManager) mContextWeakReference.get().getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(uri);

        //Setting title of request
        request.setTitle("Data Download");

        //Setting description of request
        request.setDescription("Android Data download using DownloadManager.");

        //Set the local destination for the downloaded file to a path
        //within the application's external files directory
        request.setDestinationInExternalFilesDir(mContextWeakReference.get(),
                Environment.DIRECTORY_DOWNLOADS, fileName);

        //Enqueue download and save into referenceId
        downloadReference = downloadManager.enqueue(request);

        return downloadReference;
    }


    @Override
    public void updateDownloadableObject(DownloadableObject downloadableItem) {

    }
}