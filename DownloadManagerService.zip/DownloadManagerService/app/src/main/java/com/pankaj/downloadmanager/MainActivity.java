package com.pankaj.downloadmanager;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.pankaj.downloadmanager.downloadmanager.DownloadManagerService;
import com.pankaj.downloadmanager.downloadmanager.beans.DownloadStatus;
import com.pankaj.downloadmanager.downloadmanager.beans.DownloadableObject;
import com.pankaj.downloadmanager.downloadmanager.utils.Constants;
import com.pankaj.downloadmanager.uxpages.DownloadableListAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<DownloadableObject> mFiles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        getDummyList();

        // specify an adapter (see also next example)
        mAdapter = new DownloadableListAdapter(MainActivity.this, mRecyclerView, mFiles);
        mRecyclerView.setAdapter(mAdapter);

        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        registerReceiver(downloadReceiver, filter);
    }

    public void buttonClicked(View v) {
        Button button = (Button) v;
        Intent service = new Intent(MainActivity.this, DownloadManagerService.class);
        if (!DownloadManagerService.IS_SERVICE_RUNNING) {
            service.setAction(Constants.Action.STARTFOREGROUND_ACTION);
            DownloadManagerService.IS_SERVICE_RUNNING = true;
            button.setText("Stop Service");
        } else {
            service.setAction(Constants.Action.STOPFOREGROUND_ACTION);
            DownloadManagerService.IS_SERVICE_RUNNING = false;
            button.setText("Start Service");

        }
        startService(service);
    }

    private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            //check if the broadcast message is for our enqueued download
            long referenceId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);

            Toast.makeText(context,
                    "Image Download Complete " + referenceId, Toast.LENGTH_LONG).show();
        }
    };

    private ArrayList<DownloadableObject> getDummyList() {
        mFiles = new ArrayList<DownloadableObject>();

       /* DownloadableObject(String id, long dmId, String objectName, int itemCoverId, DownloadStatus downloadStatus, String objectUrl, int downloadPercent, int lastEmittedDownloadPercent) {

        }*/

        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.COMPLETED, "http://sherly.mobile9.com/download/media/550/cutehatsun_y2FkUEgM.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.FAILED, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.IN_PROGRESS, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.PAUSED, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.QUEUED, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://sherly.mobile9.com/download/media/550/cutehatsun_y2FkUEgM.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 10,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 20,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 30,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://sherly.mobile9.com/download/media/550/cutehatsun_y2FkUEgM.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 50,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 10,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://sherly.mobile9.com/download/media/550/cutehatsun_y2FkUEgM.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 7,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 87,0));
        mFiles.add(new DownloadableObject("1", -1, "Test", 0, DownloadStatus.NEW, "http://www.coolandroidwallpapers.com/wp-content/uploads/Cute/Cute%20Android%20Wallpapers%20HD%2073.jpg", 0,0));

        return mFiles;
    }
}
