package com.pankaj.downloadmanager.downloadmanager.utils;

import android.app.DownloadManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;

import com.pankaj.downloadmanager.downloadmanager.beans.DownloadPercent;
import com.pankaj.downloadmanager.downloadmanager.beans.DownloadableObject;

import java.util.ArrayList;

import io.reactivex.ObservableEmitter;

/**
 * Created by Pankaj Kumar on 7/15/2017.
 * pankaj.arrah@gmail.com
 */
public class DMUtils {
    private static final String TAG = DMUtils.class.getSimpleName();

    /**
     * It emits percent of downloading object and status of the downloading object. Status can be used to
     * know if downloading object is being downloaded or failed or paused.
     *
     * This method will be called itself after
     * {@link com.pankaj.downloadmanager.downloadmanager.utils.Constants.DownloadConfig#DEALAY_STATUS_QUERY }.
     *
     *
     * @param downloadManager - {@link DownloadManager}
     * @param downloadableObject - {@link DownloadableObject}
     * @param observableEmitter - {@link ObservableEmitter}
     */
    public static void queryDownloadPercents(final DownloadManager downloadManager,
                                             final DownloadableObject downloadableObject,
                                             final ObservableEmitter observableEmitter) {

        //If the emitter has been disposed, then return.
        if (downloadManager == null || downloadableObject == null || observableEmitter == null
                || observableEmitter.isDisposed()) {
            return;
        }

        long lastEmittedDownloadPercent = downloadableObject.getLastEmittedDownloadPercent();


        DownloadPercent downloadPercent = queryDownloadPercent(downloadManager, downloadableObject.getDmId());

        if (downloadPercent == null) {
            return;
        }

        //Get the current DownloadPercent and download status
        float currentDownloadPercent = downloadPercent.getPercent();
        int downloadStatus = downloadPercent.getDownloadStatus();
        downloadableObject.setDownloadPercent((int) currentDownloadPercent);
        if ((currentDownloadPercent - lastEmittedDownloadPercent >= Constants.DownloadConfig.MIN_DIFF_PRCNT_TO_EMIT_STATUS) ||
                currentDownloadPercent == Constants.DownloadConfig.PERCENT_COMPLETED) {
            observableEmitter.onNext(downloadableObject);
            downloadableObject.setLastEmittedDownloadPercent((int) currentDownloadPercent);
        }
        DMLog.d(TAG,
                "STATUS from Download manager database DownloadStatus is "
                        + downloadStatus + " and downloadPercent is " + currentDownloadPercent);
        switch (downloadStatus) {
            case DownloadManager.STATUS_FAILED:
                break;

            case DownloadManager.STATUS_SUCCESSFUL:
                break;

            case DownloadManager.STATUS_PENDING:
            case DownloadManager.STATUS_RUNNING:
            case DownloadManager.STATUS_PAUSED:
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        queryDownloadPercents(downloadManager, downloadableObject, observableEmitter);
                    }
                }, Constants.DownloadConfig.DEALAY_STATUS_QUERY);
                break;

            case DownloadManager.ERROR_FILE_ERROR:
                break;
        }
    }

    /**
     * Add given downloadUrl to {@link DownloadManager} for download.
     * Download will be started and id for the object which is being downloaded will be returned.
     *
     * @param downloadManager - {@link DownloadManager}, can not be null.
     * @param downloadUrl     - Url of object which will be downloaded. Can not be null
     * @return id of the object which is being downloaded,
     * or {@link com.pankaj.downloadmanager.downloadmanager.utils.Constants.DownloadConfig#DEFAULT_ID}
     * if required arguments are not valid.
     */
    public static long enqueueToDownloadManager(DownloadManager downloadManager, String downloadUrl) {
        if (downloadManager == null || downloadUrl == null || TextUtils.isEmpty(downloadUrl.trim())) {
            return Constants.DownloadConfig.DEFAULT_ID;
        }
        Uri uri = Uri.parse(downloadUrl);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        return downloadManager.enqueue(request);
    }


    private static DownloadPercent queryDownloadPercent(DownloadManager downloadManager, long lookupId) {

        //Create a query with downloadId as the filter.
        DownloadManager.Query query = new DownloadManager.Query();
        query.setFilterById(lookupId);

        //Create an instance of downloadable result
        DownloadPercent downloadableResult = new DownloadPercent();
        downloadableResult.setDownloadingId(lookupId);

        Cursor cursor = null;
        try {
            cursor = downloadManager.query(query);
            if (cursor == null || !cursor.moveToFirst()) {
                return downloadableResult;
            }
            //Get the download percent
            float bytesDownloaded =
                    cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            float bytesTotal =
                    cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            int downloadPercent = (int) ((bytesDownloaded / bytesTotal) * 100);
            if (downloadPercent <= Constants.DownloadConfig.PERCENT_COMPLETED) {
                downloadableResult.setPercent(downloadPercent);
            }
            //Get the download status
            int columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
            int downloadStatus = cursor.getInt(columnIndex);
            downloadableResult.setDownloadStatus(downloadStatus);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return downloadableResult;
    }


    private static ArrayList<DownloadPercent> queryDownloadPercent(DownloadManager downloadManager, ArrayList<Long> downloadingIds) {

        ArrayList<DownloadPercent> result = new ArrayList<DownloadPercent>();
        for (long id : downloadingIds) {

            result.add(queryDownloadPercent(downloadManager, id));
        }

        return result;
    }

}


