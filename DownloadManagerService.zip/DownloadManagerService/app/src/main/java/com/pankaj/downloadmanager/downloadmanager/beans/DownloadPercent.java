package com.pankaj.downloadmanager.downloadmanager.beans;

/**
 * Created by Pankaj Kumar on 7/15/2017.
 * pankaj.arrah@gmail.com
 */
public class DownloadPercent {
    private long mDownloadingId;
    private float mPercent;
    private int mStatus;

    public float getPercent() {
        return mPercent;
    }

    public void setPercent(float percent) {
        this.mPercent = percent;
    }

    public int getDownloadStatus() {
        return mStatus;
    }

    public void setDownloadStatus(int downloadStatus) {
        this.mStatus = downloadStatus;
    }

    public long getDownloadingId() {
        return mDownloadingId;
    }

    public void setDownloadingId(long downloadingId) {
        this.mDownloadingId = downloadingId;
    }

    @Override
    public String toString() {
        return "DownloadPercent{" +
                "mPercent=" + mPercent +
                ", mStatus=" + mStatus +
                ", mDownloadingId=" + mDownloadingId +
                '}';
    }
}
