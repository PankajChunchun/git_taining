package com.pankaj.downloadmanager;

/**
 * Created by Pankaj Kumar on 7/16/2017.
 * pankaj.arrah@gmail.com
 */
public class DownloadObjStore {
    /*public static ArrayList getItems(Context context) {
        ArrayList<DownloadableItem> downloadableItems = new ArrayList<>();

        if (context == null) {
            return downloadableItems;
        }

        Resources res = context.getResources();
        String[] imagesId = res.getStringArray(R.array.image_ids);
        String[] imagesDisplayNamesList = res.getStringArray(R.array.image_display_names_list);
        String[] imageDownloadUrlList = res.getStringArray(R.array.image_download_url_list);
        TypedArray imageDownloadCoverList = res.obtainTypedArray(R.array.image_download_cover_list);

        for (int i = 0; i < imagesId.length; i++) {
            DownloadableItem downloadableItem = new DownloadableItem();
            String itemId = imagesId[i];
            downloadableItem.setId(itemId);
            String downloadingStatus = getDownloadStatus(context, itemId);
            downloadableItem.setDownloadingStatus(DownloadingStatus.getValue(downloadingStatus));
            downloadableItem.setItemTitle(imagesDisplayNamesList[i]);
            downloadableItem.setItemCoverId(imageDownloadCoverList.getResourceId(i, 0));
            downloadableItem.setItemDownloadUrl(imageDownloadUrlList[i]);
            downloadableItems.add(downloadableItem);
        }
        return downloadableItems;
    }*/
}
